"""
Enhanced Database Module with Shared Database Support
======================================================
Supports both PostgreSQL (shared) and SQLite (standalone)
"""

import sqlite3
import threading
import time
from contextlib import contextmanager
from datetime import datetime
import config

# Try import PostgreSQL adapter
try:
    import psycopg2
    from psycopg2 import pool
    from psycopg2.extras import RealDictCursor
    POSTGRES_AVAILABLE = True
except ImportError:
    POSTGRES_AVAILABLE = False
    print("⚠️ psycopg2 not installed. PostgreSQL support disabled.")

# Import logger
try:
    from logger import logger, log_error_with_context
except ImportError:
    class FallbackLogger:
        def info(self, msg, **kwargs): print(f"ℹ️ {msg}")
        def warning(self, msg, **kwargs): print(f"⚠️ {msg}")
        def error(self, msg, **kwargs): print(f"❌ {msg}")
        def debug(self, msg, **kwargs): pass
    logger = FallbackLogger()
    def log_error_with_context(e, ctx, **kwargs): print(f"❌ Error in {ctx}: {e}")

# ==========================================
# CONNECTION POOL (PostgreSQL)
# ==========================================
_pg_pool = None

def get_pg_pool():
    """Get or create PostgreSQL connection pool"""
    global _pg_pool
    
    if _pg_pool is None and config.DATABASE_TYPE == 'postgresql':
        if not POSTGRES_AVAILABLE:
            raise ImportError("psycopg2 not installed. Install with: pip install psycopg2-binary")
        
        if not config.DATABASE_URL:
            raise ValueError("DATABASE_URL not configured for PostgreSQL")
        
        try:
            _pg_pool = psycopg2.pool.ThreadedConnectionPool(
                minconn=1,
                maxconn=config.DB_MAX_CONNECTIONS,
                dsn=config.DATABASE_URL
            )
            logger.info("✅ PostgreSQL connection pool created")
        except Exception as e:
            logger.error(f"Failed to create PostgreSQL pool: {e}")
            raise
    
    return _pg_pool

# ==========================================
# CONNECTION POOL (SQLite)
# ==========================================
class SQLiteConnectionPool:
    """Thread-safe connection pool for SQLite"""
    
    def __init__(self, database, max_connections=10):
        self.database = database
        self.max_connections = max_connections
        self.connections = []
        self.lock = threading.Lock()
        self._local = threading.local()
    
    def get_connection(self):
        """Get a connection from pool"""
        if hasattr(self._local, 'conn') and self._local.conn:
            return self._local.conn
        
        with self.lock:
            if self.connections:
                conn = self.connections.pop()
            else:
                conn = sqlite3.connect(
                    self.database,
                    timeout=config.DB_TIMEOUT,
                    check_same_thread=False
                )
                conn.row_factory = sqlite3.Row
                conn.execute("PRAGMA journal_mode=WAL")
                conn.execute("PRAGMA synchronous=NORMAL")
            
            self._local.conn = conn
            return conn
    
    def return_connection(self, conn):
        """Return connection to pool"""
        if conn:
            with self.lock:
                if len(self.connections) < self.max_connections:
                    self.connections.append(conn)
                else:
                    conn.close()
    
    def close_all(self):
        """Close all connections"""
        with self.lock:
            for conn in self.connections:
                try:
                    conn.close()
                except:
                    pass
            self.connections.clear()

_sqlite_pool = None

def get_sqlite_pool():
    """Get or create SQLite connection pool"""
    global _sqlite_pool
    if _sqlite_pool is None and config.DATABASE_TYPE == 'sqlite':
        _sqlite_pool = SQLiteConnectionPool(config.DB_FILE)
    return _sqlite_pool

# ==========================================
# CONTEXT MANAGER
# ==========================================
@contextmanager
def get_db_connection(commit=True):
    """
    Context manager for database connections
    Supports both PostgreSQL and SQLite
    """
    if config.DATABASE_TYPE == 'postgresql':
        # PostgreSQL connection
        pool = get_pg_pool()
        conn = None
        retry_count = 0
        max_retries = config.DB_MAX_RETRY_ATTEMPTS
        
        while retry_count < max_retries:
            try:
                conn = pool.getconn()
                yield conn
                
                if commit:
                    conn.commit()
                break
                
            except Exception as e:
                if conn and commit:
                    try:
                        conn.rollback()
                    except:
                        pass
                
                retry_count += 1
                if retry_count < max_retries:
                    logger.warning(f"Database error, retry {retry_count}/{max_retries}")
                    time.sleep(config.DB_RETRY_DELAY * retry_count)
                    continue
                raise
            
            finally:
                if conn:
                    pool.putconn(conn)
    
    else:
        # SQLite connection
        pool = get_sqlite_pool()
        conn = None
        retry_count = 0
        max_retries = config.DB_MAX_RETRY_ATTEMPTS
        
        while retry_count < max_retries:
            try:
                conn = pool.get_connection()
                yield conn
                
                if commit:
                    conn.commit()
                break
                
            except sqlite3.OperationalError as e:
                if "database is locked" in str(e).lower():
                    retry_count += 1
                    if retry_count < max_retries:
                        logger.warning(f"Database locked, retry {retry_count}/{max_retries}")
                        time.sleep(config.DB_RETRY_DELAY * retry_count)
                        if conn:
                            try:
                                conn.rollback()
                            except:
                                pass
                        continue
                    else:
                        logger.error(f"Database locked after {max_retries} retries")
                        raise
                else:
                    raise
            
            except Exception as e:
                if conn and commit:
                    try:
                        conn.rollback()
                    except:
                        pass
                raise
            
            finally:
                if conn:
                    pool.return_connection(conn)

# ==========================================
# CURSOR HELPER
# ==========================================
def dict_cursor(conn):
    """Get cursor that returns dict-like rows"""
    if config.DATABASE_TYPE == 'postgresql':
        return conn.cursor(cursor_factory=RealDictCursor)
    else:
        return conn.cursor()

# ==========================================
# DATABASE INITIALIZATION
# ==========================================
def init_database():
    """Initialize database tables"""
    try:
        with get_db_connection() as conn:
            cursor = dict_cursor(conn)
            
            if config.DATABASE_TYPE == 'postgresql':
                # PostgreSQL - tables should already exist from schema
                # Just verify they exist
                cursor.execute("""
                    SELECT table_name FROM information_schema.tables 
                    WHERE table_schema = 'public' AND table_name IN ('users', 'topups', 'orders', 'stock')
                """)
                tables = [row['table_name'] if isinstance(row, dict) else row[0] for row in cursor.fetchall()]
                
                if len(tables) < 4:
                    logger.warning("Some tables missing. Please run shared_db_schema.sql")
                    return False
                
                logger.info("✅ PostgreSQL tables verified")
            
            else:
                # SQLite - create tables
                # SHARED TABLES
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS users (
                        user_id INTEGER PRIMARY KEY,
                        balance INTEGER DEFAULT 0,
                        total_topup INTEGER DEFAULT 0,
                        total_spent INTEGER DEFAULT 0,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS topups (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER NOT NULL,
                        amount INTEGER NOT NULL,
                        order_id TEXT UNIQUE NOT NULL,
                        status TEXT DEFAULT 'pending',
                        payment_type TEXT,
                        bot_source TEXT DEFAULT 'order',
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (user_id) REFERENCES users(user_id)
                    )
                ''')
                
                # ORDER BOT TABLES
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS orders (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        order_number TEXT UNIQUE NOT NULL,
                        user_id INTEGER NOT NULL,
                        package_type TEXT NOT NULL,
                        code_quantity INTEGER NOT NULL,
                        total_price INTEGER NOT NULL,
                        status TEXT DEFAULT 'pending',
                        payment_method TEXT DEFAULT 'balance',
                        delivery_status TEXT DEFAULT 'pending',
                        delivery_method TEXT DEFAULT 'dm',
                        notes TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        completed_at TIMESTAMP,
                        FOREIGN KEY (user_id) REFERENCES users(user_id)
                    )
                ''')
                
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS stock (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        code TEXT NOT NULL,
                        code_type TEXT DEFAULT 'redfinger',
                        is_available INTEGER DEFAULT 1,
                        is_encrypted INTEGER DEFAULT 0,
                        added_by INTEGER,
                        added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        reserved_for_order INTEGER,
                        used_at TIMESTAMP,
                        used_by INTEGER,
                        FOREIGN KEY (reserved_for_order) REFERENCES orders(id),
                        FOREIGN KEY (used_by) REFERENCES users(user_id)
                    )
                ''')
                
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS deliveries (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        order_id INTEGER NOT NULL,
                        user_id INTEGER NOT NULL,
                        delivery_method TEXT NOT NULL,
                        status TEXT DEFAULT 'pending',
                        attempt_count INTEGER DEFAULT 0,
                        delivered_at TIMESTAMP,
                        error_message TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (order_id) REFERENCES orders(id),
                        FOREIGN KEY (user_id) REFERENCES users(user_id)
                    )
                ''')
                
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS order_items (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        order_id INTEGER NOT NULL,
                        stock_id INTEGER NOT NULL,
                        delivered INTEGER DEFAULT 0,
                        delivered_at TIMESTAMP,
                        FOREIGN KEY (order_id) REFERENCES orders(id),
                        FOREIGN KEY (stock_id) REFERENCES stock(id)
                    )
                ''')
                
                # Create indexes
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_topups_user_id ON topups(user_id)')
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_topups_order_id ON topups(order_id)')
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id)')
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status)')
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_stock_available ON stock(is_available)')
                
                logger.info("✅ SQLite tables created")
            
            return True
            
    except Exception as e:
        log_error_with_context(e, "init_database")
        raise

# ==========================================
# SHARED USER OPERATIONS (Used by both bots)
# ==========================================
def get_balance(user_id):
    """Get user balance - SHARED with redeem bot"""
    try:
        with get_db_connection(commit=False) as conn:
            cursor = dict_cursor(conn)
            
            if config.DATABASE_TYPE == 'postgresql':
                cursor.execute("SELECT balance FROM users WHERE user_id = %s", (user_id,))
            else:
                cursor.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
            
            row = cursor.fetchone()
            
            if row:
                return row['balance'] if isinstance(row, dict) else row[0]
            else:
                # Create new user
                if config.DATABASE_TYPE == 'postgresql':
                    cursor.execute("INSERT INTO users (user_id, balance) VALUES (%s, 0)", (user_id,))
                else:
                    cursor.execute("INSERT INTO users (user_id, balance) VALUES (?, 0)", (user_id,))
                conn.commit()
                logger.info(f"Created new user: {user_id}", user_id=user_id)
                return 0
                
    except Exception as e:
        log_error_with_context(e, "get_balance", user_id=user_id)
        return 0

def add_balance(user_id, amount):
    """Add balance to user - SHARED"""
    try:
        with get_db_connection() as conn:
            cursor = dict_cursor(conn)
            
            # Ensure user exists
            if config.DATABASE_TYPE == 'postgresql':
                cursor.execute("INSERT INTO users (user_id, balance) VALUES (%s, 0) ON CONFLICT (user_id) DO NOTHING", (user_id,))
                cursor.execute("""
                    UPDATE users 
                    SET balance = balance + %s,
                        total_topup = total_topup + %s,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE user_id = %s
                    RETURNING balance
                """, (amount, amount, user_id))
                row = cursor.fetchone()
                new_balance = row['balance'] if row else 0
            else:
                cursor.execute("INSERT OR IGNORE INTO users (user_id, balance) VALUES (?, 0)", (user_id,))
                cursor.execute("""
                    UPDATE users 
                    SET balance = balance + ?,
                        total_topup = total_topup + ?,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE user_id = ?
                """, (amount, amount, user_id))
                cursor.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
                row = cursor.fetchone()
                new_balance = row[0] if row else 0
            
            logger.info(f"Added Rp {amount:,}. New balance: Rp {new_balance:,}", user_id=user_id)
            return new_balance
            
    except Exception as e:
        log_error_with_context(e, "add_balance", user_id=user_id)
        raise

def deduct_balance(user_id, amount):
    """Deduct balance from user - SHARED"""
    try:
        with get_db_connection() as conn:
            cursor = dict_cursor(conn)
            
            # Check balance
            if config.DATABASE_TYPE == 'postgresql':
                cursor.execute("SELECT balance FROM users WHERE user_id = %s", (user_id,))
            else:
                cursor.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
            
            row = cursor.fetchone()
            if not row:
                logger.warning(f"User not found for deduction", user_id=user_id)
                return False
            
            current_balance = row['balance'] if isinstance(row, dict) else row[0]
            
            if current_balance < amount:
                logger.warning(f"Insufficient balance. Need: Rp {amount:,}, Have: Rp {current_balance:,}", user_id=user_id)
                return False
            
            # Deduct
            if config.DATABASE_TYPE == 'postgresql':
                cursor.execute("""
                    UPDATE users 
                    SET balance = balance - %s,
                        total_spent = total_spent + %s,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE user_id = %s
                """, (amount, amount, user_id))
            else:
                cursor.execute("""
                    UPDATE users 
                    SET balance = balance - ?,
                        total_spent = total_spent + ?,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE user_id = ?
                """, (amount, amount, user_id))
            
            new_balance = current_balance - amount
            logger.info(f"Deducted Rp {amount:,}. New balance: Rp {new_balance:,}", user_id=user_id)
            return True
            
    except Exception as e:
        log_error_with_context(e, "deduct_balance", user_id=user_id)
        return False

def get_user_stats(user_id):
    """Get user statistics - SHARED"""
    try:
        with get_db_connection(commit=False) as conn:
            cursor = dict_cursor(conn)
            
            # Get user data
            if config.DATABASE_TYPE == 'postgresql':
                cursor.execute("SELECT * FROM users WHERE user_id = %s", (user_id,))
            else:
                cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
            
            user_row = cursor.fetchone()
            
            if not user_row:
                return {
                    'balance': 0,
                    'total_topup': 0,
                    'total_spent': 0,
                    'total_orders': 0,
                    'completed_orders': 0,
                    'pending_orders': 0
                }
            
            # Get order stats
            if config.DATABASE_TYPE == 'postgresql':
                cursor.execute("""
                    SELECT 
                        COUNT(*) as total_orders,
                        COUNT(*) FILTER (WHERE status = 'completed') as completed_orders,
                        COUNT(*) FILTER (WHERE status = 'pending') as pending_orders
                    FROM orders 
                    WHERE user_id = %s
                """, (user_id,))
            else:
                cursor.execute("""
                    SELECT 
                        COUNT(*) as total_orders,
                        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_orders,
                        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_orders
                    FROM orders 
                    WHERE user_id = ?
                """, (user_id,))
            
            order_row = cursor.fetchone()
            
            if isinstance(user_row, dict):
                result = {
                    'balance': user_row['balance'],
                    'total_topup': user_row['total_topup'],
                    'total_spent': user_row['total_spent'],
                }
            else:
                result = {
                    'balance': user_row[1],
                    'total_topup': user_row[2],
                    'total_spent': user_row[3],
                }
            
            if order_row:
                if isinstance(order_row, dict):
                    result.update({
                        'total_orders': order_row['total_orders'] or 0,
                        'completed_orders': order_row['completed_orders'] or 0,
                        'pending_orders': order_row['pending_orders'] or 0
                    })
                else:
                    result.update({
                        'total_orders': order_row[0] or 0,
                        'completed_orders': order_row[1] or 0,
                        'pending_orders': order_row[2] or 0
                    })
            else:
                result.update({
                    'total_orders': 0,
                    'completed_orders': 0,
                    'pending_orders': 0
                })
            
            return result
            
    except Exception as e:
        log_error_with_context(e, "get_user_stats", user_id=user_id)
        return {
            'balance': 0,
            'total_topup': 0,
            'total_spent': 0,
            'total_orders': 0,
            'completed_orders': 0,
            'pending_orders': 0
        }

# ==========================================
# TOPUP OPERATIONS (SHARED)
# ==========================================
def create_topup(user_id, amount, order_id):
    """Create topup transaction - SHARED"""
    try:
        with get_db_connection() as conn:
            cursor = dict_cursor(conn)
            
            # Ensure user exists
            if config.DATABASE_TYPE == 'postgresql':
                cursor.execute("INSERT INTO users (user_id, balance) VALUES (%s, 0) ON CONFLICT (user_id) DO NOTHING", (user_id,))
                cursor.execute("""
                    INSERT INTO topups (user_id, amount, order_id, status, bot_source)
                    VALUES (%s, %s, %s, 'pending', 'order')
                """, (user_id, amount, order_id))
            else:
                cursor.execute("INSERT OR IGNORE INTO users (user_id, balance) VALUES (?, 0)", (user_id,))
                cursor.execute("""
                    INSERT INTO topups (user_id, amount, order_id, status, bot_source)
                    VALUES (?, ?, ?, 'pending', 'order')
                """, (user_id, amount, order_id))
            
            logger.info(f"Created topup: {order_id} | Rp {amount:,}", user_id=user_id)
            return True
            
    except Exception as e:
        log_error_with_context(e, "create_topup", user_id=user_id)
        return False

def update_topup_status(order_id, status, raw_data=None):
    """Update topup status - SHARED"""
    try:
        with get_db_connection() as conn:
            cursor = dict_cursor(conn)
            
            if config.DATABASE_TYPE == 'postgresql':
                cursor.execute("""
                    UPDATE topups 
                    SET status = %s,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE order_id = %s
                """, (status, order_id))
            else:
                cursor.execute("""
                    UPDATE topups 
                    SET status = ?,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE order_id = ?
                """, (status, order_id))
            
            if cursor.rowcount > 0:
                logger.info(f"Updated topup: {order_id} → {status}")
                return True
            else:
                logger.warning(f"Topup not found: {order_id}")
                return False
                
    except Exception as e:
        log_error_with_context(e, "update_topup_status")
        return False

def get_topup_by_order_id(order_id):
    """Get topup by order_id - SHARED"""
    try:
        with get_db_connection(commit=False) as conn:
            cursor = dict_cursor(conn)
            
            if config.DATABASE_TYPE == 'postgresql':
                cursor.execute("SELECT * FROM topups WHERE order_id = %s", (order_id,))
            else:
                cursor.execute("SELECT * FROM topups WHERE order_id = ?", (order_id,))
            
            row = cursor.fetchone()
            
            if row:
                if isinstance(row, dict):
                    return dict(row)
                else:
                    # Convert sqlite3.Row to dict
                    return {
                        'id': row[0],
                        'user_id': row[1],
                        'amount': row[2],
                        'order_id': row[3],
                        'status': row[4],
                        'payment_type': row[5],
                        'bot_source': row[6],
                        'created_at': row[7],
                        'updated_at': row[8]
                    }
            return None
            
    except Exception as e:
        log_error_with_context(e, "get_topup_by_order_id")
        return None

# ==========================================
# ORDER OPERATIONS
# ==========================================
def create_order(user_id, package_type, code_quantity, total_price, payment_method='balance'):
    """Create new order"""
    try:
        with get_db_connection() as conn:
            cursor = dict_cursor(conn)
            
            # Generate order number
            timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
            order_number = f"ORD-{user_id}-{timestamp}"
            
            if config.DATABASE_TYPE == 'postgresql':
                cursor.execute("""
                    INSERT INTO orders (
                        order_number, user_id, package_type, code_quantity, 
                        total_price, status, payment_method
                    )
                    VALUES (%s, %s, %s, %s, %s, 'pending', %s)
                    RETURNING id
                """, (order_number, user_id, package_type, code_quantity, total_price, payment_method))
                order_id = cursor.fetchone()['id']
            else:
                cursor.execute("""
                    INSERT INTO orders (
                        order_number, user_id, package_type, code_quantity,
                        total_price, status, payment_method
                    )
                    VALUES (?, ?, ?, ?, ?, 'pending', ?)
                """, (order_number, user_id, package_type, code_quantity, total_price, payment_method))
                order_id = cursor.lastrowid
            
            logger.info(f"Created order: {order_number} | {code_quantity} codes | Rp {total_price:,}", user_id=user_id)
            return order_id, order_number
            
    except Exception as e:
        log_error_with_context(e, "create_order", user_id=user_id)
        return None, None

def get_order_by_id(order_id):
    """Get order by ID"""
    try:
        with get_db_connection(commit=False) as conn:
            cursor = dict_cursor(conn)
            
            if config.DATABASE_TYPE == 'postgresql':
                cursor.execute("SELECT * FROM orders WHERE id = %s", (order_id,))
            else:
                cursor.execute("SELECT * FROM orders WHERE id = ?", (order_id,))
            
            row = cursor.fetchone()
            if row:
                return dict(row) if isinstance(row, dict) else dict(zip([d[0] for d in cursor.description], row))
            return None
            
    except Exception as e:
        log_error_with_context(e, "get_order_by_id")
        return None

def get_order_by_number(order_number):
    """Get order by order number"""
    try:
        with get_db_connection(commit=False) as conn:
            cursor = dict_cursor(conn)
            
            if config.DATABASE_TYPE == 'postgresql':
                cursor.execute("SELECT * FROM orders WHERE order_number = %s", (order_number,))
            else:
                cursor.execute("SELECT * FROM orders WHERE order_number = ?", (order_number,))
            
            row = cursor.fetchone()
            if row:
                return dict(row) if isinstance(row, dict) else dict(zip([d[0] for d in cursor.description], row))
            return None
            
    except Exception as e:
        log_error_with_context(e, "get_order_by_number")
        return None

def update_order_status(order_id, status, delivery_status=None):
    """Update order status"""
    try:
        with get_db_connection() as conn:
            cursor = dict_cursor(conn)
            
            if delivery_status:
                if config.DATABASE_TYPE == 'postgresql':
                    cursor.execute("""
                        UPDATE orders 
                        SET status = %s, delivery_status = %s,
                            completed_at = CASE WHEN %s = 'completed' THEN CURRENT_TIMESTAMP ELSE completed_at END
                        WHERE id = %s
                    """, (status, delivery_status, status, order_id))
                else:
                    cursor.execute("""
                        UPDATE orders 
                        SET status = ?, delivery_status = ?,
                            completed_at = CASE WHEN ? = 'completed' THEN CURRENT_TIMESTAMP ELSE completed_at END
                        WHERE id = ?
                    """, (status, delivery_status, status, order_id))
            else:
                if config.DATABASE_TYPE == 'postgresql':
                    cursor.execute("""
                        UPDATE orders 
                        SET status = %s,
                            completed_at = CASE WHEN %s = 'completed' THEN CURRENT_TIMESTAMP ELSE completed_at END
                        WHERE id = %s
                    """, (status, status, order_id))
                else:
                    cursor.execute("""
                        UPDATE orders 
                        SET status = ?,
                            completed_at = CASE WHEN ? = 'completed' THEN CURRENT_TIMESTAMP ELSE completed_at END
                        WHERE id = ?
                    """, (status, status, order_id))
            
            logger.info(f"Updated order {order_id}: {status}")
            return cursor.rowcount > 0
            
    except Exception as e:
        log_error_with_context(e, "update_order_status")
        return False

def get_user_orders(user_id, limit=10):
    """Get user's recent orders"""
    try:
        with get_db_connection(commit=False) as conn:
            cursor = dict_cursor(conn)
            
            if config.DATABASE_TYPE == 'postgresql':
                cursor.execute("""
                    SELECT * FROM orders 
                    WHERE user_id = %s 
                    ORDER BY created_at DESC 
                    LIMIT %s
                """, (user_id, limit))
            else:
                cursor.execute("""
                    SELECT * FROM orders 
                    WHERE user_id = ? 
                    ORDER BY created_at DESC 
                    LIMIT ?
                """, (user_id, limit))
            
            rows = cursor.fetchall()
            return [dict(row) if isinstance(row, dict) else dict(zip([d[0] for d in cursor.description], row)) for row in rows]
            
    except Exception as e:
        log_error_with_context(e, "get_user_orders", user_id=user_id)
        return []

# ==========================================
# STOCK OPERATIONS
# ==========================================
def add_stock_code(code, code_type='redfinger', added_by=None, is_encrypted=False):
    """Add code to stock"""
    try:
        with get_db_connection() as conn:
            cursor = dict_cursor(conn)
            
            if config.DATABASE_TYPE == 'postgresql':
                cursor.execute("""
                    INSERT INTO stock (code, code_type, is_available, is_encrypted, added_by)
                    VALUES (%s, %s, TRUE, %s, %s)
                    RETURNING id
                """, (code, code_type, is_encrypted, added_by))
                stock_id = cursor.fetchone()['id']
            else:
                cursor.execute("""
                    INSERT INTO stock (code, code_type, is_available, is_encrypted, added_by)
                    VALUES (?, ?, 1, ?, ?)
                """, (code, code_type, 1 if is_encrypted else 0, added_by))
                stock_id = cursor.lastrowid
            
            logger.info(f"Added stock code: ID={stock_id}")
            return stock_id
            
    except Exception as e:
        log_error_with_context(e, "add_stock_code")
        return None

def get_available_stock_count(code_type='redfinger'):
    """Get count of available stock"""
    try:
        with get_db_connection(commit=False) as conn:
            cursor = dict_cursor(conn)
            
            if config.DATABASE_TYPE == 'postgresql':
                cursor.execute("""
                    SELECT COUNT(*) as count FROM stock 
                    WHERE is_available = TRUE AND code_type = %s AND reserved_for_order IS NULL
                """, (code_type,))
            else:
                cursor.execute("""
                    SELECT COUNT(*) as count FROM stock 
                    WHERE is_available = 1 AND code_type = ? AND reserved_for_order IS NULL
                """, (code_type,))
            
            row = cursor.fetchone()
            return row['count'] if isinstance(row, dict) else row[0]
            
    except Exception as e:
        log_error_with_context(e, "get_available_stock_count")
        return 0

def reserve_stock_codes(order_id, quantity, code_type='redfinger'):
    """Reserve stock codes for an order"""
    try:
        with get_db_connection() as conn:
            cursor = dict_cursor(conn)
            
            # Get available codes
            if config.DATABASE_TYPE == 'postgresql':
                cursor.execute("""
                    SELECT id FROM stock 
                    WHERE is_available = TRUE AND code_type = %s AND reserved_for_order IS NULL
                    LIMIT %s
                    FOR UPDATE
                """, (code_type, quantity))
            else:
                cursor.execute("""
                    SELECT id FROM stock 
                    WHERE is_available = 1 AND code_type = ? AND reserved_for_order IS NULL
                    LIMIT ?
                """, (code_type, quantity))
            
            rows = cursor.fetchall()
            stock_ids = [row['id'] if isinstance(row, dict) else row[0] for row in rows]
            
            if len(stock_ids) < quantity:
                logger.warning(f"Insufficient stock. Need: {quantity}, Available: {len(stock_ids)}")
                return []
            
            # Reserve codes
            for stock_id in stock_ids:
                if config.DATABASE_TYPE == 'postgresql':
                    cursor.execute("UPDATE stock SET reserved_for_order = %s WHERE id = %s", (order_id, stock_id))
                else:
                    cursor.execute("UPDATE stock SET reserved_for_order = ? WHERE id = ?", (order_id, stock_id))
            
            logger.info(f"Reserved {len(stock_ids)} codes for order {order_id}")
            return stock_ids
            
    except Exception as e:
        log_error_with_context(e, "reserve_stock_codes")
        return []

def get_reserved_codes(order_id):
    """Get codes reserved for an order"""
    try:
        with get_db_connection(commit=False) as conn:
            cursor = dict_cursor(conn)
            
            if config.DATABASE_TYPE == 'postgresql':
                cursor.execute("SELECT * FROM stock WHERE reserved_for_order = %s", (order_id,))
            else:
                cursor.execute("SELECT * FROM stock WHERE reserved_for_order = ?", (order_id,))
            
            rows = cursor.fetchall()
            return [dict(row) if isinstance(row, dict) else dict(zip([d[0] for d in cursor.description], row)) for row in rows]
            
    except Exception as e:
        log_error_with_context(e, "get_reserved_codes")
        return []

def mark_codes_as_used(stock_ids, user_id):
    """Mark codes as used"""
    try:
        with get_db_connection() as conn:
            cursor = dict_cursor(conn)
            
            for stock_id in stock_ids:
                if config.DATABASE_TYPE == 'postgresql':
                    cursor.execute("""
                        UPDATE stock 
                        SET is_available = FALSE, used_at = CURRENT_TIMESTAMP, used_by = %s
                        WHERE id = %s
                    """, (user_id, stock_id))
                else:
                    cursor.execute("""
                        UPDATE stock 
                        SET is_available = 0, used_at = CURRENT_TIMESTAMP, used_by = ?
                        WHERE id = ?
                    """, (user_id, stock_id))
            
            logger.info(f"Marked {len(stock_ids)} codes as used")
            return True
            
    except Exception as e:
        log_error_with_context(e, "mark_codes_as_used")
        return False

# ==========================================
# STATISTICS
# ==========================================
def get_database_stats():
    """Get overall database statistics"""
    try:
        with get_db_connection(commit=False) as conn:
            cursor = dict_cursor(conn)
            
            # Total users
            cursor.execute("SELECT COUNT(*) as count FROM users")
            total_users = cursor.fetchone()
            total_users = total_users['count'] if isinstance(total_users, dict) else total_users[0]
            
            # Total balance
            cursor.execute("SELECT SUM(balance) as total FROM users")
            total_balance = cursor.fetchone()
            total_balance = (total_balance['total'] if isinstance(total_balance, dict) else total_balance[0]) or 0
            
            # Order stats
            if config.DATABASE_TYPE == 'postgresql':
                cursor.execute("""
                    SELECT 
                        COUNT(*) as total_orders,
                        COUNT(*) FILTER (WHERE status = 'completed') as completed_orders,
                        COUNT(*) FILTER (WHERE status = 'pending') as pending_orders,
                        SUM(total_price) FILTER (WHERE status = 'completed') as total_revenue
                    FROM orders
                """)
            else:
                cursor.execute("""
                    SELECT 
                        COUNT(*) as total_orders,
                        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_orders,
                        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_orders,
                        SUM(CASE WHEN status = 'completed' THEN total_price ELSE 0 END) as total_revenue
                    FROM orders
                """)
            
            order_stats = cursor.fetchone()
            
            # Stock stats
            if config.DATABASE_TYPE == 'postgresql':
                cursor.execute("""
                    SELECT 
                        COUNT(*) as total_stock,
                        COUNT(*) FILTER (WHERE is_available = TRUE) as available_stock
                    FROM stock
                """)
            else:
                cursor.execute("""
                    SELECT 
                        COUNT(*) as total_stock,
                        SUM(CASE WHEN is_available = 1 THEN 1 ELSE 0 END) as available_stock
                    FROM stock
                """)
            
            stock_stats = cursor.fetchone()
            
            result = {
                'total_users': total_users,
                'total_balance': total_balance,
            }
            
            if order_stats:
                if isinstance(order_stats, dict):
                    result.update({
                        'total_orders': order_stats['total_orders'] or 0,
                        'completed_orders': order_stats['completed_orders'] or 0,
                        'pending_orders': order_stats['pending_orders'] or 0,
                        'total_revenue': order_stats['total_revenue'] or 0
                    })
                else:
                    result.update({
                        'total_orders': order_stats[0] or 0,
                        'completed_orders': order_stats[1] or 0,
                        'pending_orders': order_stats[2] or 0,
                        'total_revenue': order_stats[3] or 0
                    })
            
            if stock_stats:
                if isinstance(stock_stats, dict):
                    result.update({
                        'total_stock': stock_stats['total_stock'] or 0,
                        'available_stock': stock_stats['available_stock'] or 0
                    })
                else:
                    result.update({
                        'total_stock': stock_stats[0] or 0,
                        'available_stock': stock_stats[1] or 0
                    })
            
            return result
            
    except Exception as e:
        log_error_with_context(e, "get_database_stats")
        return {
            'total_users': 0,
            'total_balance': 0,
            'total_orders': 0,
            'completed_orders': 0,
            'pending_orders': 0,
            'total_revenue': 0,
            'total_stock': 0,
            'available_stock': 0
        }
